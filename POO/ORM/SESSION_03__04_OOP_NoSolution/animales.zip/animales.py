# -*- coding: utf-8 -*-
"""
Created on Fri Jun 18 12:05:57 2021

@author: manoe
"""

class Perro:
    contador_clase = 0
    nombre = ''
    es_peludo = True
    sitios = []
    
    def ladrido_pkt(self): # La función es persistente
        self.contador_clase += 1 # Esta variable es también persistente
        print("Au au! {}".format(self.contador_clase))
    
class Gato:
    def miau(self,veces=1):
        print("Miau! "*veces)
#ladrido()