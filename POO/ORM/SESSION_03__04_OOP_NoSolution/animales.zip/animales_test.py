# -*- coding: utf-8 -*-
"""
Created on Fri Jun 18 12:07:29 2021

@author: manoe
"""

contador = 0

def ladrido():
    global contador
    contador = contador + 1 
    print("Au au! {}".format(contador))

ladrido()
ladrido()
ladrido()
ladrido()
ladrido()



import animales

kio = animales.Perro()
kio.ladrido_pkt()
kio.ladrido_pkt()
kio.ladrido_pkt()
kio.ladrido_pkt()
kio.ladrido_pkt()

yako = animales.Perro()
yako.ladrido_pkt()
yako.ladrido_pkt()


rosita = animales.Gato()
rosita.miau(6)


rosita.ladrido_pkt()

yako.miau(6)
